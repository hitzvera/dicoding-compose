package com.dicoding.jetreward.model

data class OrderReward(
    val reward: Reward,
    val count: Int
)